# Vishal Sekar - Resume Website
Built with Next.js, React, TailwindCSS, and Framer Motion. Deployed via Vercel.
